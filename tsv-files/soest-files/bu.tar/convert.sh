#!/bin/bash


for filename in ./*.tsv
do
  newName=`echo $filename | sed 's/tsv/csv/g'`
  #echo $filename $newName
  echo convert.pl ./$filename > ./$newName
done